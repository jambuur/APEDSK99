Layer 1 = APEDSK-AU-Top-Data
Layer 2 = APEDSK-AU-Layer2-Power
Layer 3 = APEDSK-AU-Layer3-Address
Layer 4 = APEDSK-AU-Bottom-GND