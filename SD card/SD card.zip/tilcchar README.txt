This is the lower case character definition file used by CALL ACHR.
It needs to be in the SD root folder.