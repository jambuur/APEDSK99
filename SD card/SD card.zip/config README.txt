To (re)configure APEDSK99, make sure it is connected to your TI99/4a and powered up. 
Soft-reset the console (FCTN QUIT) and go into TI BASIC (NOT Extended Basic!).

- Map the AD99SUP.DSK to DSK1: 		CALL MDSK(1,"AD99SUP")
- Load the configuration program: 	OLD DSK1.ACFG
- Run the program:			RUN

You'll be asked to enter information about your network so be prepared to have the following information ready:

- APEDSK99 IP address (tip: use 99 for the final octet ;-) )
- FTP Server address
- NTP Server address
- FTP username and password (depending on the FTP server, these could be case sensitive)
- Your timezone in hours difference with UTC time (ranges from -12 to +14)	

After applying the configuration and resetting APEDSK99, the program will show local date/time.
If these seem correct, it's a good indication APEDSK99 is configured properly.

Other things to try to see if the APEDSK99 configuration is working:

- try to ping it at it's new IP address	
- FTP a DSK image to/from your FTP server

Any problems just ping me on AtariAge (JJB).